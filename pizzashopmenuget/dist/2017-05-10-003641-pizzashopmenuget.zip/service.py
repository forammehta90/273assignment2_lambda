import boto3

# -*- coding: utf-8 -*-


def handler(event, context):
    client = boto3.client("dynamodb")
    return client.get_item(TableName="pizzashopmenu",Key=event)