import boto3

# -*- coding: utf-8 -*-


def handler(event, context):
    client = boto3.client("dynamodb")
    client.get_item(Tablename="pizzashopmenu",Key=event)