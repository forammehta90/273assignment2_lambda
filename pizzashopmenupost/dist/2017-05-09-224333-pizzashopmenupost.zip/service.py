import boto3
import json
# -*- coding: utf-8 -*-


def handler(event, context):
    # Your code goes here!
    client = boto3.client("dynamodb")

    selection = []
    for item in event["selection"]:
        it=dict()
        it["S"]=item
        selection.append(it)
    price = []
    for item in event["price"]:
        it=dict()
        it["S"]=item
        price.append(it)
    size = []
    for item in event["size"]:
        it=dict()
        it["S"]=item
        size.append(it)

    client.put_item(TableName="pizzashopmenu",Item={"menu_id":{"S":event[menu_id]},"store_name":{"S":event[store_name]},"selection":{"L":event[selection]},"price":{"L":event[price]},"size":{"L":event[size]}})