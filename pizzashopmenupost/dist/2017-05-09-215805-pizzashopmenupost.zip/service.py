import boto3

# -*- coding: utf-8 -*-


def handler(event, context):
    print "Hi"    